# Documentação do Projeto Terraform

## Visão Geral

Este projeto Terraform implementa uma infraestrutura na AWS composta por um bucket S3, uma função Lambda, um API Gateway e as IAM roles necessárias. A estrutura segue as melhores práticas de
organização de código Terraform, utilizando módulos reutilizáveis e separação por ambientes.

## Estrutura do Projeto

.
├── main.tf                 # Arquivo principal que orquestra os módulos
├── variables.tf            # Variáveis globais do projeto
├── outputs.tf              # Outputs globais do projeto
├── modules/                # Diretório contendo os módulos reutilizáveis
│   ├── s3/                 # Módulo para o bucket S3
│   ├── lambda/             # Módulo para a função Lambda
│   ├── api_gateway/        # Módulo para o API Gateway
│   └── iam/                # Módulo para as IAM roles
└── environments/           # Configurações específicas por ambiente
    ├── dev/                # Ambiente de desenvolvimento
    └── prod/               # Ambiente de produção


## Módulos

### Módulo S3

Este módulo cria um bucket S3 com as seguintes configurações:
• Versionamento habilitado
• Criptografia do lado do servidor (AES256)
• Bloqueio de acesso público
• Nomenclatura baseada no nome do projeto e ambiente

### Módulo IAM

Este módulo cria:
• Uma IAM role para a função Lambda
• Uma política que permite à Lambda acessar o bucket S3 e criar logs no CloudWatch
• Anexa a política à role

### Módulo Lambda

Este módulo cria:
• Uma função Lambda usando Node.js 18.x
• Um arquivo ZIP contendo o código da função
• Um grupo de logs no CloudWatch para a função
• Configuração de variáveis de ambiente (nome do bucket S3)

### Módulo API Gateway

Este módulo cria:
• Um API Gateway HTTP (v2)
• Um estágio de implantação
• Integração com a função Lambda
• Configuração de CORS
• Logs no CloudWatch
• Permissão para o API Gateway invocar a função Lambda

## Ambientes

O projeto suporta múltiplos ambientes (dev e prod) com configurações específicas para cada um. Cada ambiente referencia os módulos principais com suas próprias variáveis.

## Como Usar

### Pré-requisitos

• Terraform v1.0.0 ou superior
• AWS CLI configurado com credenciais válidas

### Implantação

Para implantar o ambiente de desenvolvimento:

bash
cd environments/dev
terraform init
terraform plan
terraform apply


Para implantar o ambiente de produção:

bash
cd environments/prod
terraform init
terraform plan
terraform apply


### Outputs

Após a implantação, os seguintes outputs estarão disponíveis:
• s3_bucket_name: Nome do bucket S3 criado
• lambda_function_name: Nome da função Lambda
• api_gateway_url: URL do API Gateway para acessar a função Lambda

## Segurança

Este projeto implementa várias práticas de segurança:
• Bucket S3 com acesso público bloqueado
• Criptografia do lado do servidor para o bucket S3
• IAM roles com privilégios mínimos necessários
• Logs habilitados para auditoria

## Personalização

Para personalizar o projeto, você pode modificar as variáveis nos arquivos:
• variables.tf (global)
• environments/dev/main.tf (ambiente de desenvolvimento)
• environments/prod/main.tf (ambiente de produção)

As principais variáveis são:
• aws_region: Região da AWS onde os recursos serão criados
• project_name: Nome do projeto usado para nomear os recursos
• environment: Ambiente (dev, prod, etc.)

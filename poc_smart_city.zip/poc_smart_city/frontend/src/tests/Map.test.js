import { render, screen, waitFor } from '@testing-library/react';
import Map from '../components/Map';

describe('Map Component', () => {
  test('renders loading state initially', () => {
    render(<Map />);
    
    // Verificar se o estado de carregamento é exibido
    expect(screen.getByText('Carregando mapa...')).toBeInTheDocument();
  });
  
  test('renders map after loading', async () => {
    render(<Map />);
    
    // Aguardar o carregamento do mapa
    await waitFor(() => {
      expect(screen.getByText('Mapa de Fortaleza')).toBeInTheDocument();
    });
    
    // Verificar se os elementos do mapa estão presentes
    expect(screen.getByText('Visualização de áreas de risco')).toBeInTheDocument();
    expect(screen.getByText('Alto Risco')).toBeInTheDocument();
    expect(screen.getByText('Médio Risco')).toBeInTheDocument();
    expect(screen.getByText('Baixo Risco')).toBeInTheDocument();
  });
  
  test('displays risk areas count', async () => {
    const mockRiskAreas = [
      { id: 1, title: 'Área 1', risk_level: 'high' },
      { id: 2, title: 'Área 2', risk_level: 'medium' },
      { id: 3, title: 'Área 3', risk_level: 'low' }
    ];
    
    render(<Map riskAreas={mockRiskAreas} />);
    
    // Aguardar o carregamento do mapa
    await waitFor(() => {
      // Verificar se o número de áreas é exibido corretamente
      expect(screen.getByText('3')).toBeInTheDocument();
    });
  });
  
  test('renders map controls', async () => {
    render(<Map />);
    
    // Aguardar o carregamento do mapa
    await waitFor(() => {
      // Verificar se os controles do mapa estão presentes
      const controls = screen.getAllByRole('button');
      expect(controls.length).toBe(3); // Zoom in, zoom out, location
    });
  });
  
  test('renders map points for risk areas', async () => {
    const mockRiskAreas = [
      { id: 1, title: 'Área 1', risk_level: 'high', latitude: -3.731, longitude: -38.526 },
      { id: 2, title: 'Área 2', risk_level: 'medium', latitude: -3.741, longitude: -38.536 }
    ];
    
    render(<Map riskAreas={mockRiskAreas} />);
    
    // Aguardar o carregamento do mapa
    await waitFor(() => {
      // Verificar se os pontos do mapa são renderizados
      // Nota: Como estamos usando uma simulação de mapa, verificamos os pontos simulados
      const mapPoints = document.querySelectorAll('.map-point');
      expect(mapPoints.length).toBeGreaterThan(0);
    });
  });
});

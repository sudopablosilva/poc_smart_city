import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Footer from '../components/Footer';

describe('Footer Component', () => {
  test('renders footer with all sections', () => {
    render(
      <BrowserRouter>
        <Footer />
      </BrowserRouter>
    );
    
    // Verificar se o título do projeto está presente
    expect(screen.getByText('Fortaleza Segura')).toBeInTheDocument();
    
    // Verificar se o slogan está presente
    expect(screen.getByText('Juntos por uma cidade mais segura.')).toBeInTheDocument();
    
    // Verificar se o copyright está presente com o ano atual
    const currentYear = new Date().getFullYear();
    expect(screen.getByText(`© ${currentYear} Fortaleza Segura. Todos os direitos reservados.`)).toBeInTheDocument();
  });
  
  test('renders links section', () => {
    render(
      <BrowserRouter>
        <Footer />
      </BrowserRouter>
    );
    
    // Verificar se o título da seção está presente
    expect(screen.getByText('Links Úteis')).toBeInTheDocument();
    
    // Verificar se os links estão presentes
    expect(screen.getByText('Início')).toBeInTheDocument();
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    expect(screen.getByText('Reportar Área')).toBeInTheDocument();
    expect(screen.getByText('Sobre')).toBeInTheDocument();
  });
  
  test('renders contact section', () => {
    render(
      <BrowserRouter>
        <Footer />
      </BrowserRouter>
    );
    
    // Verificar se o título da seção está presente
    expect(screen.getByText('Contato')).toBeInTheDocument();
    
    // Verificar se as informações de contato estão presentes
    expect(screen.getByText('Email: contato@fortalezasegura.com.br')).toBeInTheDocument();
    expect(screen.getByText('Telefone: (85) 9999-9999')).toBeInTheDocument();
    
    // Verificar se os links de redes sociais estão presentes
    const socialLinks = screen.getAllByRole('link', { name: '' });
    expect(socialLinks.length).toBe(3); // Facebook, Twitter, Instagram
  });
});

import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter, MemoryRouter } from 'react-router-dom';
import App from '../App';
import Home from '../pages/Home';
import Dashboard from '../pages/Dashboard';
import ReportRisk from '../pages/ReportRisk';
import Profile from '../pages/Profile';
import { riskAreaService, userService } from '../services/api';

// Mock dos serviços de API
jest.mock('../services/api', () => ({
  riskAreaService: {
    getAll: jest.fn(),
    getStats: jest.fn(),
    create: jest.fn()
  },
  riskTypeService: {
    getAll: jest.fn()
  },
  neighborhoodService: {
    getAll: jest.fn()
  },
  userService: {
    getProfile: jest.fn(),
    updateProfile: jest.fn(),
    login: jest.fn(),
    register: jest.fn()
  }
}));

// Mock dos componentes que usam recursos externos
jest.mock('../components/Map', () => () => <div data-testid="mock-map">Map Component</div>);

describe('Integration Tests', () => {
  beforeEach(() => {
    // Reset dos mocks antes de cada teste
    jest.clearAllMocks();
    
    // Mock de dados padrão
    riskAreaService.getAll.mockResolvedValue({
      data: [
        {
          id: 1,
          title: 'Área de Risco 1',
          risk_type_name: 'Alagamento',
          risk_level: 'high',
          neighborhood_name: 'Centro',
          status: 'pending',
          created_at: '2023-05-15T10:30:00Z'
        }
      ]
    });
    
    riskAreaService.getStats.mockResolvedValue({
      data: {
        total: 50,
        by_status: [
          { status: 'pending', count: 20 },
          { status: 'resolved', count: 15 }
        ],
        by_risk_level: [],
        by_risk_type: [],
        recent: 10
      }
    });
    
    userService.getProfile.mockResolvedValue({
      data: {
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        first_name: 'Test',
        last_name: 'User',
        bio: 'Test bio',
        reported_areas_count: 5
      }
    });
  });
  
  test('Home page loads and displays risk areas map', async () => {
    render(
      <BrowserRouter>
        <Home />
      </BrowserRouter>
    );
    
    // Verificar se o título principal está presente
    expect(screen.getByText('Fortaleza Segura')).toBeInTheDocument();
    
    // Verificar se o mapa é renderizado
    expect(screen.getByTestId('mock-map')).toBeInTheDocument();
    
    // Verificar se os botões de ação estão presentes
    expect(screen.getByText('Reportar Área de Risco')).toBeInTheDocument();
    expect(screen.getByText('Ver Dashboard')).toBeInTheDocument();
  });
  
  test('Dashboard page loads and displays filters', async () => {
    render(
      <BrowserRouter>
        <Dashboard />
      </BrowserRouter>
    );
    
    // Verificar se o título está presente
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    
    // Verificar se os filtros estão presentes
    expect(screen.getByText('Filtros')).toBeInTheDocument();
    expect(screen.getByLabelText('Tipo de Risco')).toBeInTheDocument();
    expect(screen.getByLabelText('Nível de Risco')).toBeInTheDocument();
    expect(screen.getByLabelText('Bairro')).toBeInTheDocument();
    expect(screen.getByLabelText('Status')).toBeInTheDocument();
    
    // Verificar se a tabela de áreas de risco está presente
    expect(screen.getByText('Áreas de Risco')).toBeInTheDocument();
  });
  
  test('ReportRisk page loads form correctly', async () => {
    render(
      <BrowserRouter>
        <ReportRisk />
      </BrowserRouter>
    );
    
    // Verificar se o título está presente
    expect(screen.getByText('Reportar Área de Risco')).toBeInTheDocument();
    
    // Verificar se os campos do formulário estão presentes
    expect(screen.getByLabelText('Título *')).toBeInTheDocument();
    expect(screen.getByLabelText('Descrição *')).toBeInTheDocument();
    expect(screen.getByLabelText('Tipo de Risco *')).toBeInTheDocument();
    expect(screen.getByText('Nível de Risco *')).toBeInTheDocument();
    
    // Verificar se os botões estão presentes
    expect(screen.getByText('Cancelar')).toBeInTheDocument();
    expect(screen.getByText('Enviar Reporte')).toBeInTheDocument();
  });
  
  test('Profile page loads user data correctly', async () => {
    render(
      <BrowserRouter>
        <Profile />
      </BrowserRouter>
    );
    
    // Verificar se o título está presente
    expect(screen.getByText('Meu Perfil')).toBeInTheDocument();
    
    // Aguardar o carregamento dos dados do perfil
    await waitFor(() => {
      // Verificar se o botão de salvar está presente
      expect(screen.getByText('Salvar Alterações')).toBeInTheDocument();
    });
  });
  
  test('Complete flow of reporting a risk area', async () => {
    // Mock da criação de área de risco
    riskAreaService.create.mockResolvedValue({
      data: {
        id: 2,
        title: 'Nova Área de Risco',
        description: 'Descrição da nova área',
        risk_type_name: 'Alagamento',
        risk_level: 'medium',
        status: 'pending'
      }
    });
    
    render(
      <BrowserRouter>
        <ReportRisk />
      </BrowserRouter>
    );
    
    // Preencher o formulário
    fireEvent.change(screen.getByLabelText('Título *'), {
      target: { value: 'Nova Área de Risco' }
    });
    
    fireEvent.change(screen.getByLabelText('Descrição *'), {
      target: { value: 'Descrição da nova área' }
    });
    
    // Selecionar tipo de risco (simulado)
    const riskTypeSelect = screen.getByLabelText('Tipo de Risco *');
    fireEvent.change(riskTypeSelect, {
      target: { value: '1' }
    });
    
    // Preencher coordenadas
    fireEvent.change(screen.getByLabelText('Latitude *'), {
      target: { value: '-3.731862' }
    });
    
    fireEvent.change(screen.getByLabelText('Longitude *'), {
      target: { value: '-38.526669' }
    });
    
    // Enviar o formulário
    fireEvent.click(screen.getByText('Enviar Reporte'));
    
    // Verificar se o serviço foi chamado
    await waitFor(() => {
      expect(riskAreaService.create).toHaveBeenCalled();
    });
  });
  
  test('User registration and login flow', async () => {
    // Mock do registro de usuário
    userService.register.mockResolvedValue({
      data: {
        user: {
          id: 2,
          username: 'newuser',
          email: 'new@example.com'
        },
        access: 'mock-token'
      }
    });
    
    // Mock do login
    userService.login.mockResolvedValue({
      data: {
        user: {
          id: 2,
          username: 'newuser',
          email: 'new@example.com'
        },
        access: 'mock-token'
      }
    });
    
    // Teste simulado de registro e login
    // Em um teste real, renderizaríamos os componentes de registro e login
    // e interagiríamos com os formulários
    
    const registerData = {
      username: 'newuser',
      email: 'new@example.com',
      password: 'password123',
      password_confirm: 'password123'
    };
    
    const loginData = {
      username: 'newuser',
      password: 'password123'
    };
    
    // Simular registro
    const registerResult = await userService.register(registerData);
    expect(registerResult.data.user.username).toBe('newuser');
    
    // Simular login
    const loginResult = await userService.login(loginData);
    expect(loginResult.data.access).toBe('mock-token');
  });
});

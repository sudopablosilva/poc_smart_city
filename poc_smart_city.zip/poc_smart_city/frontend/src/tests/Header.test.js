import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Header from '../components/Header';
import { userService } from '../services/api';

// Mock do serviço de usuário
jest.mock('../services/api', () => ({
  userService: {
    logout: jest.fn()
  }
}));

// Mock do useNavigate
const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate
}));

describe('Header Component', () => {
  beforeEach(() => {
    // Limpar mocks antes de cada teste
    jest.clearAllMocks();
    
    // Limpar localStorage antes de cada teste
    localStorage.clear();
  });
  
  test('renders header with logo and navigation', () => {
    render(
      <BrowserRouter>
        <Header />
      </BrowserRouter>
    );
    
    // Verificar se o logo está presente
    expect(screen.getByText('Fortaleza Segura')).toBeInTheDocument();
    
    // Verificar se os links de navegação estão presentes
    expect(screen.getByText('Início')).toBeInTheDocument();
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
    expect(screen.getByText('Reportar Área')).toBeInTheDocument();
  });
  
  test('shows login and register buttons when user is not logged in', () => {
    render(
      <BrowserRouter>
        <Header />
      </BrowserRouter>
    );
    
    // Verificar se os botões de login e registro estão presentes
    expect(screen.getByText('Entrar')).toBeInTheDocument();
    expect(screen.getByText('Cadastrar')).toBeInTheDocument();
    
    // Verificar se o botão de logout não está presente
    expect(screen.queryByText('Sair')).not.toBeInTheDocument();
  });
  
  test('shows profile and logout buttons when user is logged in', () => {
    // Simular usuário logado
    localStorage.setItem('authToken', 'fake-token');
    localStorage.setItem('user', JSON.stringify({ id: 1, name: 'Test User' }));
    
    render(
      <BrowserRouter>
        <Header />
      </BrowserRouter>
    );
    
    // Verificar se o link de perfil está presente
    expect(screen.getByText('Perfil')).toBeInTheDocument();
    
    // Verificar se o botão de logout está presente
    expect(screen.getByText('Sair')).toBeInTheDocument();
    
    // Verificar se os botões de login e registro não estão presentes
    expect(screen.queryByText('Entrar')).not.toBeInTheDocument();
    expect(screen.queryByText('Cadastrar')).not.toBeInTheDocument();
  });
  
  test('logout button calls logout function and redirects to home', () => {
    // Simular usuário logado
    localStorage.setItem('authToken', 'fake-token');
    localStorage.setItem('user', JSON.stringify({ id: 1, name: 'Test User' }));
    
    render(
      <BrowserRouter>
        <Header />
      </BrowserRouter>
    );
    
    // Clicar no botão de logout
    fireEvent.click(screen.getByText('Sair'));
    
    // Verificar se a função de logout foi chamada
    expect(userService.logout).toHaveBeenCalled();
    
    // Verificar se o redirecionamento foi chamado
    expect(mockNavigate).toHaveBeenCalledWith('/');
    
    // Verificar se o localStorage foi limpo
    expect(localStorage.getItem('authToken')).toBeNull();
    expect(localStorage.getItem('user')).toBeNull();
  });
});

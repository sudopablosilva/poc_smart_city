import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import App from '../App';

// Mock dos componentes para evitar erros de renderização
jest.mock('../components/Header', () => () => <div data-testid="mock-header">Header</div>);
jest.mock('../components/Footer', () => () => <div data-testid="mock-footer">Footer</div>);
jest.mock('../pages/Home', () => () => <div data-testid="mock-home">Home Page</div>);

test('renders app structure with header, main content and footer', () => {
  render(
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
  
  // Verificar se o header está presente
  const headerElement = screen.getByTestId('mock-header');
  expect(headerElement).toBeInTheDocument();
  
  // Verificar se o conteúdo principal está presente
  const mainElement = screen.getByRole('main');
  expect(mainElement).toBeInTheDocument();
  expect(mainElement).toHaveClass('App-main');
  
  // Verificar se o footer está presente
  const footerElement = screen.getByTestId('mock-footer');
  expect(footerElement).toBeInTheDocument();
});

test('renders home page by default', () => {
  render(
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
  
  // Verificar se a página inicial é renderizada por padrão
  const homeElement = screen.getByTestId('mock-home');
  expect(homeElement).toBeInTheDocument();
});

test('has correct CSS classes', () => {
  render(
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
  
  // Verificar se a div principal tem a classe App
  const appElement = screen.getByTestId('mock-header').parentElement;
  expect(appElement).toHaveClass('App');
});

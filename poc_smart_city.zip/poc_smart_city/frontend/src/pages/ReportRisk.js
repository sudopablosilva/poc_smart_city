import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ReportRisk.css';
import { riskAreaService, riskTypeService, neighborhoodService } from '../services/api';

const ReportRisk = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [riskTypes, setRiskTypes] = useState([]);
  const [neighborhoods, setNeighborhoods] = useState([]);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    latitude: '',
    longitude: '',
    risk_type: '',
    risk_level: 'medium',
    neighborhood: '',
    images: []
  });
  
  const [currentLocation, setCurrentLocation] = useState(null);
  const [locationError, setLocationError] = useState(null);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Dados simulados para desenvolvimento
        const mockRiskTypes = [
          { id: 1, name: 'Alagamento', color: '#3498db', icon: 'water' },
          { id: 2, name: 'Deslizamento', color: '#e74c3c', icon: 'mountain' },
          { id: 3, name: 'Incêndio', color: '#e67e22', icon: 'fire' },
          { id: 4, name: 'Estrutura Comprometida', color: '#9b59b6', icon: 'building-damage' },
          { id: 5, name: 'Falta de Iluminação', color: '#f1c40f', icon: 'lightbulb' }
        ];
        
        const mockNeighborhoods = [
          { id: 1, name: 'Centro' },
          { id: 2, name: 'Aldeota' },
          { id: 3, name: 'Meireles' },
          { id: 4, name: 'Benfica' },
          { id: 5, name: 'Fátima' }
        ];
        
        // Em um ambiente real, usaríamos as chamadas de API abaixo
        // const [riskTypesResponse, neighborhoodsResponse] = await Promise.all([
        //   riskTypeService.getAll(),
        //   neighborhoodService.getAll()
        // ]);
        
        setRiskTypes(mockRiskTypes);
        setNeighborhoods(mockNeighborhoods);
      } catch (err) {
        console.error('Error fetching form data:', err);
        setError('Não foi possível carregar os dados do formulário. Tente novamente mais tarde.');
      }
    };

    fetchData();
    getCurrentLocation();
  }, []);
  
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCurrentLocation({ latitude, longitude });
          setFormData(prev => ({
            ...prev,
            latitude: latitude.toFixed(6),
            longitude: longitude.toFixed(6)
          }));
        },
        (error) => {
          console.error('Error getting location:', error);
          setLocationError('Não foi possível obter sua localização atual. Por favor, insira manualmente.');
        }
      );
    } else {
      setLocationError('Geolocalização não é suportada pelo seu navegador. Por favor, insira a localização manualmente.');
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setFormData(prev => ({ ...prev, images: [...prev.images, ...files] }));
  };
  
  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validação básica
    if (!formData.title || !formData.description || !formData.latitude || !formData.longitude || !formData.risk_type || !formData.risk_level) {
      setError('Por favor, preencha todos os campos obrigatórios.');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      // Em um ambiente real, enviaríamos os dados para a API
      // const response = await riskAreaService.create(formData);
      
      // Simulando uma chamada de API bem-sucedida
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSuccess(true);
      setLoading(false);
      
      // Redirecionar após alguns segundos
      setTimeout(() => {
        navigate('/dashboard');
      }, 3000);
    } catch (err) {
      console.error('Error submitting report:', err);
      setError('Ocorreu um erro ao enviar o reporte. Por favor, tente novamente.');
      setLoading(false);
    }
  };
  
  if (success) {
    return (
      <div className="report-risk-page">
        <div className="container">
          <div className="success-message">
            <div className="success-icon">
              <i className="fas fa-check-circle"></i>
            </div>
            <h2>Reporte Enviado com Sucesso!</h2>
            <p>Obrigado por contribuir para uma Fortaleza mais segura.</p>
            <p>Você será redirecionado para o Dashboard em alguns segundos...</p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="report-risk-page">
      <div className="container">
        <h1>Reportar Área de Risco</h1>
        
        {error && (
          <div className="error-message">
            <i className="fas fa-exclamation-circle"></i> {error}
          </div>
        )}
        
        <div className="report-form-container">
          <form onSubmit={handleSubmit} className="report-form">
            <div className="form-section">
              <h2>Informações Básicas</h2>
              
              <div className="form-group">
                <label htmlFor="title">Título *</label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="Ex: Área alagada na Rua Principal"
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="description">Descrição *</label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Descreva detalhadamente a situação de risco..."
                  rows="4"
                  required
                ></textarea>
              </div>
              
              <div className="form-group">
                <label htmlFor="risk_type">Tipo de Risco *</label>
                <select
                  id="risk_type"
                  name="risk_type"
                  value={formData.risk_type}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Selecione o tipo de risco</option>
                  {riskTypes.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>
              
              <div className="form-group">
                <label>Nível de Risco *</label>
                <div className="risk-level-options">
                  <label className="risk-level-option">
                    <input
                      type="radio"
                      name="risk_level"
                      value="low"
                      checked={formData.risk_level === 'low'}
                      onChange={handleInputChange}
                    />
                    <span className="risk-level-badge low">Baixo</span>
                  </label>
                  
                  <label className="risk-level-option">
                    <input
                      type="radio"
                      name="risk_level"
                      value="medium"
                      checked={formData.risk_level === 'medium'}
                      onChange={handleInputChange}
                    />
                    <span className="risk-level-badge medium">Médio</span>
                  </label>
                  
                  <label className="risk-level-option">
                    <input
                      type="radio"
                      name="risk_level"
                      value="high"
                      checked={formData.risk_level === 'high'}
                      onChange={handleInputChange}
                    />
                    <span className="risk-level-badge high">Alto</span>
                  </label>
                </div>
              </div>
            </div>
            
            <div className="form-section">
              <h2>Localização</h2>
              
              {locationError && (
                <div className="location-error">
                  <i className="fas fa-map-marker-alt"></i> {locationError}
                </div>
              )}
              
              <div className="location-map">
                <div className="map-placeholder">
                  <div className="map-overlay">
                    <h3>Mapa de Localização</h3>
                    <p>Clique no mapa para selecionar a localização exata</p>
                    
                    {currentLocation && (
                      <div className="current-location">
                        <i className="fas fa-crosshairs"></i> Localização atual detectada
                      </div>
                    )}
                  </div>
                  
                  {/* Ponto simulando a localização selecionada */}
                  <div className="map-point selected" style={{ top: '50%', left: '50%' }}></div>
                </div>
                
                <div className="location-controls">
                  <button type="button" className="btn-location" onClick={getCurrentLocation}>
                    <i className="fas fa-crosshairs"></i> Usar Minha Localização
                  </button>
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="latitude">Latitude *</label>
                  <input
                    type="text"
                    id="latitude"
                    name="latitude"
                    value={formData.latitude}
                    onChange={handleInputChange}
                    placeholder="Ex: -3.731862"
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="longitude">Longitude *</label>
                  <input
                    type="text"
                    id="longitude"
                    name="longitude"
                    value={formData.longitude}
                    onChange={handleInputChange}
                    placeholder="Ex: -38.526669"
                    required
                  />
                </div>
              </div>
              
              <div className="form-group">
                <label htmlFor="neighborhood">Bairro</label>
                <select
                  id="neighborhood"
                  name="neighborhood"
                  value={formData.neighborhood}
                  onChange={handleInputChange}
                >
                  <option value="">Selecione o bairro</option>
                  {neighborhoods.map(neighborhood => (
                    <option key={neighborhood.id} value={neighborhood.id}>{neighborhood.name}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="form-section">
              <h2>Imagens</h2>
              <p className="form-help">Adicione fotos da área de risco para ajudar na identificação e avaliação.</p>
              
              <div className="form-group">
                <label htmlFor="images">Selecionar Imagens</label>
                <input
                  type="file"
                  id="images"
                  name="images"
                  onChange={handleImageChange}
                  accept="image/*"
                  multiple
                  className="file-input"
                />
                <label htmlFor="images" className="file-input-label">
                  <i className="fas fa-cloud-upload-alt"></i> Escolher Arquivos
                </label>
              </div>
              
              {formData.images.length > 0 && (
                <div className="image-preview-container">
                  {formData.images.map((image, index) => (
                    <div key={index} className="image-preview">
                      <img src={URL.createObjectURL(image)} alt={`Preview ${index}`} />
                      <button 
                        type="button" 
                        className="remove-image" 
                        onClick={() => removeImage(index)}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <div className="form-actions">
              <button 
                type="button" 
                className="btn-secondary" 
                onClick={() => navigate(-1)}
              >
                Cancelar
              </button>
              <button 
                type="submit" 
                className="btn-primary" 
                disabled={loading}
              >
                {loading ? (
                  <>
                    <i className="fas fa-spinner fa-spin"></i> Enviando...
                  </>
                ) : (
                  'Enviar Reporte'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ReportRisk;

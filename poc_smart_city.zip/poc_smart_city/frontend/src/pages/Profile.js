import React, { useState, useEffect } from 'react';
import './Profile.css';
import { userService, neighborhoodService } from '../services/api';

const Profile = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [neighborhoods, setNeighborhoods] = useState([]);
  
  const [profile, setProfile] = useState({
    id: null,
    user: null,
    username: '',
    email: '',
    first_name: '',
    last_name: '',
    bio: '',
    phone: '',
    address: '',
    neighborhood: '',
    avatar: null,
    is_public_servant: false,
    organization: '',
    reported_areas_count: 0
  });
  
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [newAvatar, setNewAvatar] = useState(null);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Dados simulados para desenvolvimento
        const mockNeighborhoods = [
          { id: 1, name: 'Centro' },
          { id: 2, name: 'Aldeota' },
          { id: 3, name: 'Meireles' },
          { id: 4, name: 'Benfica' },
          { id: 5, name: 'Fátima' }
        ];
        
        const mockProfile = {
          id: 1,
          user: 1,
          username: 'joaosilva',
          email: 'joao.silva@example.com',
          first_name: 'João',
          last_name: 'Silva',
          bio: 'Cidadão preocupado com a segurança da cidade.',
          phone: '(85) 99999-9999',
          address: 'Rua Principal, 123',
          neighborhood: 2,
          neighborhood_name: 'Aldeota',
          avatar: null,
          is_public_servant: false,
          organization: '',
          reported_areas_count: 5
        };
        
        // Em um ambiente real, usaríamos as chamadas de API abaixo
        // const [profileResponse, neighborhoodsResponse] = await Promise.all([
        //   userService.getProfile(),
        //   neighborhoodService.getAll()
        // ]);
        
        setNeighborhoods(mockNeighborhoods);
        setProfile(mockProfile);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching profile data:', err);
        setError('Não foi possível carregar os dados do perfil. Tente novamente mais tarde.');
        setLoading(false);
      }
    };

    fetchData();
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  const handleAvatarChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setNewAvatar(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setSaving(true);
      setError(null);
      
      // Em um ambiente real, enviaríamos os dados para a API
      // const formData = new FormData();
      // Object.keys(profile).forEach(key => {
      //   if (key !== 'avatar' && key !== 'username' && key !== 'email' && key !== 'reported_areas_count') {
      //     formData.append(key, profile[key]);
      //   }
      // });
      // 
      // if (newAvatar) {
      //   formData.append('avatar', newAvatar);
      // }
      // 
      // await userService.updateProfile(profile.id, formData);
      
      // Simulando uma chamada de API bem-sucedida
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSuccess(true);
      setSaving(false);
      
      // Limpar mensagem de sucesso após alguns segundos
      setTimeout(() => {
        setSuccess(false);
      }, 5000);
    } catch (err) {
      console.error('Error updating profile:', err);
      setError('Ocorreu um erro ao atualizar o perfil. Por favor, tente novamente.');
      setSaving(false);
    }
  };
  
  if (loading) {
    return (
      <div className="profile-page">
        <div className="container">
          <h1>Meu Perfil</h1>
          <div className="loading">Carregando perfil...</div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="profile-page">
      <div className="container">
        <h1>Meu Perfil</h1>
        
        {error && (
          <div className="error-message">
            <i className="fas fa-exclamation-circle"></i> {error}
          </div>
        )}
        
        {success && (
          <div className="success-message">
            <i className="fas fa-check-circle"></i> Perfil atualizado com sucesso!
          </div>
        )}
        
        <div className="profile-container">
          <div className="profile-sidebar">
            <div className="avatar-container">
              {avatarPreview || profile.avatar ? (
                <img 
                  src={avatarPreview || profile.avatar} 
                  alt="Avatar" 
                  className="avatar-image" 
                />
              ) : (
                <div className="avatar-placeholder">
                  <i className="fas fa-user"></i>
                </div>
              )}
              
              <label htmlFor="avatar" className="avatar-upload-btn">
                <i className="fas fa-camera"></i>
                <span>Alterar foto</span>
              </label>
              <input 
                type="file" 
                id="avatar" 
                name="avatar" 
                onChange={handleAvatarChange} 
                accept="image/*" 
                className="avatar-input" 
              />
            </div>
            
            <div className="profile-stats">
              <div className="stat-item">
                <div className="stat-value">{profile.reported_areas_count}</div>
                <div className="stat-label">Áreas Reportadas</div>
              </div>
            </div>
            
            <div className="profile-info">
              <div className="info-item">
                <div className="info-label">Usuário</div>
                <div className="info-value">{profile.username}</div>
              </div>
              
              <div className="info-item">
                <div className="info-label">Email</div>
                <div className="info-value">{profile.email}</div>
              </div>
              
              <div className="info-item">
                <div className="info-label">Membro desde</div>
                <div className="info-value">Maio 2023</div>
              </div>
            </div>
          </div>
          
          <div className="profile-content">
            <form onSubmit={handleSubmit} className="profile-form">
              <div className="form-section">
                <h2>Informações Pessoais</h2>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="first_name">Nome</label>
                    <input
                      type="text"
                      id="first_name"
                      name="first_name"
                      value={profile.first_name}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="last_name">Sobrenome</label>
                    <input
                      type="text"
                      id="last_name"
                      name="last_name"
                      value={profile.last_name}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                
                <div className="form-group">
                  <label htmlFor="bio">Biografia</label>
                  <textarea
                    id="bio"
                    name="bio"
                    value={profile.bio}
                    onChange={handleInputChange}
                    rows="4"
                  ></textarea>
                </div>
                
                <div className="form-group">
                  <label htmlFor="phone">Telefone</label>
                  <input
                    type="text"
                    id="phone"
                    name="phone"
                    value={profile.phone}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="form-section">
                <h2>Endereço</h2>
                
                <div className="form-group">
                  <label htmlFor="address">Endereço</label>
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={profile.address}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="neighborhood">Bairro</label>
                  <select
                    id="neighborhood"
                    name="neighborhood"
                    value={profile.neighborhood}
                    onChange={handleInputChange}
                  >
                    <option value="">Selecione o bairro</option>
                    {neighborhoods.map(neighborhood => (
                      <option key={neighborhood.id} value={neighborhood.id}>{neighborhood.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="form-section">
                <h2>Informações Adicionais</h2>
                
                <div className="form-group checkbox-group">
                  <input
                    type="checkbox"
                    id="is_public_servant"
                    name="is_public_servant"
                    checked={profile.is_public_servant}
                    onChange={handleInputChange}
                  />
                  <label htmlFor="is_public_servant">Sou servidor público</label>
                </div>
                
                {profile.is_public_servant && (
                  <div className="form-group">
                    <label htmlFor="organization">Organização/Órgão</label>
                    <input
                      type="text"
                      id="organization"
                      name="organization"
                      value={profile.organization}
                      onChange={handleInputChange}
                    />
                  </div>
                )}
              </div>
              
              <div className="form-actions">
                <button 
                  type="submit" 
                  className="btn-primary" 
                  disabled={saving}
                >
                  {saving ? (
                    <>
                      <i className="fas fa-spinner fa-spin"></i> Salvando...
                    </>
                  ) : (
                    'Salvar Alterações'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

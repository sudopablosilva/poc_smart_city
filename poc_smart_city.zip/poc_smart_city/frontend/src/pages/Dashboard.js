import React, { useState, useEffect } from 'react';
import './Dashboard.css';
import { riskAreaService, riskTypeService, neighborhoodService } from '../services/api';

const Dashboard = () => {
  const [riskAreas, setRiskAreas] = useState([]);
  const [riskTypes, setRiskTypes] = useState([]);
  const [neighborhoods, setNeighborhoods] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    total: 0,
    by_status: [],
    by_risk_level: [],
    by_risk_type: [],
    recent: 0
  });
  
  // Filtros
  const [filters, setFilters] = useState({
    risk_type: '',
    risk_level: '',
    neighborhood: '',
    status: '',
    date_range: '30'
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Dados simulados para desenvolvimento
        const mockRiskTypes = [
          { id: 1, name: 'Alagamento', color: '#3498db', icon: 'water' },
          { id: 2, name: 'Deslizamento', color: '#e74c3c', icon: 'mountain' },
          { id: 3, name: 'Incêndio', color: '#e67e22', icon: 'fire' },
          { id: 4, name: 'Estrutura Comprometida', color: '#9b59b6', icon: 'building-damage' },
          { id: 5, name: 'Falta de Iluminação', color: '#f1c40f', icon: 'lightbulb' }
        ];
        
        const mockNeighborhoods = [
          { id: 1, name: 'Centro' },
          { id: 2, name: 'Aldeota' },
          { id: 3, name: 'Meireles' },
          { id: 4, name: 'Benfica' },
          { id: 5, name: 'Fátima' }
        ];
        
        const mockRiskAreas = Array(50).fill().map((_, i) => ({
          id: i + 1,
          title: `Área de Risco ${i + 1}`,
          latitude: -3.7 - Math.random() * 0.2,
          longitude: -38.5 - Math.random() * 0.2,
          risk_type: mockRiskTypes[Math.floor(Math.random() * mockRiskTypes.length)].id,
          risk_type_name: mockRiskTypes[Math.floor(Math.random() * mockRiskTypes.length)].name,
          risk_level: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)],
          neighborhood: mockNeighborhoods[Math.floor(Math.random() * mockNeighborhoods.length)].id,
          neighborhood_name: mockNeighborhoods[Math.floor(Math.random() * mockNeighborhoods.length)].name,
          status: ['pending', 'verified', 'resolved', 'rejected'][Math.floor(Math.random() * 4)],
          created_at: new Date(Date.now() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000).toISOString()
        }));
        
        const mockStats = {
          total: mockRiskAreas.length,
          by_status: [
            { status: 'pending', count: 18 },
            { status: 'verified', count: 12 },
            { status: 'resolved', count: 15 },
            { status: 'rejected', count: 5 }
          ],
          by_risk_level: [
            { risk_level: 'low', count: 15 },
            { risk_level: 'medium', count: 20 },
            { risk_level: 'high', count: 15 }
          ],
          by_risk_type: mockRiskTypes.map(type => ({
            risk_type__name: type.name,
            count: Math.floor(Math.random() * 15) + 5
          })),
          recent: 12
        };
        
        // Em um ambiente real, usaríamos as chamadas de API abaixo
        // const [riskAreasResponse, riskTypesResponse, neighborhoodsResponse, statsResponse] = await Promise.all([
        //   riskAreaService.getAll(filters),
        //   riskTypeService.getAll(),
        //   neighborhoodService.getAll(),
        //   riskAreaService.getStats()
        // ]);
        
        setRiskAreas(mockRiskAreas);
        setRiskTypes(mockRiskTypes);
        setNeighborhoods(mockNeighborhoods);
        setStats(mockStats);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Não foi possível carregar os dados do dashboard. Tente novamente mais tarde.');
        setLoading(false);
      }
    };

    fetchData();
  }, [filters]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const resetFilters = () => {
    setFilters({
      risk_type: '',
      risk_level: '',
      neighborhood: '',
      status: '',
      date_range: '30'
    });
  };

  const getStatusLabel = (status) => {
    const statusMap = {
      'pending': 'Pendente',
      'verified': 'Verificado',
      'resolved': 'Resolvido',
      'rejected': 'Rejeitado'
    };
    return statusMap[status] || status;
  };

  const getRiskLevelLabel = (level) => {
    const levelMap = {
      'low': 'Baixo',
      'medium': 'Médio',
      'high': 'Alto'
    };
    return levelMap[level] || level;
  };

  const getStatusClass = (status) => {
    const classMap = {
      'pending': 'status-pending',
      'verified': 'status-verified',
      'resolved': 'status-resolved',
      'rejected': 'status-rejected'
    };
    return classMap[status] || '';
  };

  const getRiskLevelClass = (level) => {
    const classMap = {
      'low': 'risk-low',
      'medium': 'risk-medium',
      'high': 'risk-high'
    };
    return classMap[level] || '';
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  if (loading) {
    return (
      <div className="dashboard-page">
        <div className="container">
          <h1>Dashboard</h1>
          <div className="loading">Carregando dados...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-page">
        <div className="container">
          <h1>Dashboard</h1>
          <div className="error">{error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <div className="container">
        <h1>Dashboard</h1>
        
        <div className="dashboard-stats">
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-map-marker-alt"></i>
            </div>
            <div className="stat-number">{stats.total}</div>
            <div className="stat-label">Total de Áreas</div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-check-circle"></i>
            </div>
            <div className="stat-number">
              {stats.by_status.find(s => s.status === 'resolved')?.count || 0}
            </div>
            <div className="stat-label">Resolvidos</div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-exclamation-triangle"></i>
            </div>
            <div className="stat-number">
              {stats.by_status.find(s => s.status === 'pending')?.count || 0}
            </div>
            <div className="stat-label">Pendentes</div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-calendar-alt"></i>
            </div>
            <div className="stat-number">{stats.recent}</div>
            <div className="stat-label">Últimos 30 dias</div>
          </div>
        </div>
        
        <div className="dashboard-filters">
          <h2>Filtros</h2>
          <div className="filters-form">
            <div className="filter-group">
              <label htmlFor="risk_type">Tipo de Risco</label>
              <select 
                id="risk_type" 
                name="risk_type" 
                value={filters.risk_type} 
                onChange={handleFilterChange}
              >
                <option value="">Todos</option>
                {riskTypes.map(type => (
                  <option key={type.id} value={type.id}>{type.name}</option>
                ))}
              </select>
            </div>
            
            <div className="filter-group">
              <label htmlFor="risk_level">Nível de Risco</label>
              <select 
                id="risk_level" 
                name="risk_level" 
                value={filters.risk_level} 
                onChange={handleFilterChange}
              >
                <option value="">Todos</option>
                <option value="low">Baixo</option>
                <option value="medium">Médio</option>
                <option value="high">Alto</option>
              </select>
            </div>
            
            <div className="filter-group">
              <label htmlFor="neighborhood">Bairro</label>
              <select 
                id="neighborhood" 
                name="neighborhood" 
                value={filters.neighborhood} 
                onChange={handleFilterChange}
              >
                <option value="">Todos</option>
                {neighborhoods.map(neighborhood => (
                  <option key={neighborhood.id} value={neighborhood.id}>{neighborhood.name}</option>
                ))}
              </select>
            </div>
            
            <div className="filter-group">
              <label htmlFor="status">Status</label>
              <select 
                id="status" 
                name="status" 
                value={filters.status} 
                onChange={handleFilterChange}
              >
                <option value="">Todos</option>
                <option value="pending">Pendente</option>
                <option value="verified">Verificado</option>
                <option value="resolved">Resolvido</option>
                <option value="rejected">Rejeitado</option>
              </select>
            </div>
            
            <div className="filter-group">
              <label htmlFor="date_range">Período</label>
              <select 
                id="date_range" 
                name="date_range" 
                value={filters.date_range} 
                onChange={handleFilterChange}
              >
                <option value="7">Últimos 7 dias</option>
                <option value="30">Últimos 30 dias</option>
                <option value="90">Últimos 90 dias</option>
                <option value="365">Último ano</option>
                <option value="">Todos</option>
              </select>
            </div>
            
            <button className="btn-reset" onClick={resetFilters}>
              Limpar Filtros
            </button>
          </div>
        </div>
        
        <div className="dashboard-charts">
          <div className="chart-container">
            <h3>Áreas por Status</h3>
            <div className="chart-placeholder">
              <div className="chart-bars">
                {stats.by_status.map((item, index) => (
                  <div key={index} className="chart-bar-container">
                    <div 
                      className={`chart-bar ${getStatusClass(item.status)}`} 
                      style={{ height: `${(item.count / stats.total) * 200}px` }}
                    >
                      <span className="chart-value">{item.count}</span>
                    </div>
                    <span className="chart-label">{getStatusLabel(item.status)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="chart-container">
            <h3>Áreas por Nível de Risco</h3>
            <div className="chart-placeholder">
              <div className="chart-bars">
                {stats.by_risk_level.map((item, index) => (
                  <div key={index} className="chart-bar-container">
                    <div 
                      className={`chart-bar ${getRiskLevelClass(item.risk_level)}`} 
                      style={{ height: `${(item.count / stats.total) * 200}px` }}
                    >
                      <span className="chart-value">{item.count}</span>
                    </div>
                    <span className="chart-label">{getRiskLevelLabel(item.risk_level)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="chart-container full-width">
            <h3>Áreas por Tipo de Risco</h3>
            <div className="chart-placeholder">
              <div className="chart-bars horizontal">
                {stats.by_risk_type.map((item, index) => (
                  <div key={index} className="chart-bar-container horizontal">
                    <span className="chart-label">{item.risk_type__name}</span>
                    <div 
                      className="chart-bar" 
                      style={{ 
                        width: `${(item.count / Math.max(...stats.by_risk_type.map(i => i.count))) * 100}%`,
                        backgroundColor: riskTypes.find(t => t.name === item.risk_type__name)?.color || '#3498db'
                      }}
                    >
                      <span className="chart-value">{item.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="dashboard-table">
          <h2>Áreas de Risco</h2>
          <div className="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Título</th>
                  <th>Tipo</th>
                  <th>Nível</th>
                  <th>Bairro</th>
                  <th>Status</th>
                  <th>Data</th>
                </tr>
              </thead>
              <tbody>
                {riskAreas.slice(0, 10).map(area => (
                  <tr key={area.id}>
                    <td>{area.id}</td>
                    <td>{area.title}</td>
                    <td>{area.risk_type_name}</td>
                    <td>
                      <span className={`badge ${getRiskLevelClass(area.risk_level)}`}>
                        {getRiskLevelLabel(area.risk_level)}
                      </span>
                    </td>
                    <td>{area.neighborhood_name}</td>
                    <td>
                      <span className={`badge ${getStatusClass(area.status)}`}>
                        {getStatusLabel(area.status)}
                      </span>
                    </td>
                    <td>{formatDate(area.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="pagination">
            <button className="btn-page" disabled>&laquo;</button>
            <button className="btn-page active">1</button>
            <button className="btn-page">2</button>
            <button className="btn-page">3</button>
            <button className="btn-page">&raquo;</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

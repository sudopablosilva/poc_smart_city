import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  return (
    <div className="home-page">
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1>Fortaleza Segura</h1>
            <p>Juntos por uma cidade mais segura. Reporte áreas de risco e ajude a comunidade.</p>
            <div className="hero-buttons">
              <Link to="/report" className="btn-primary">
                <i className="fas fa-exclamation-triangle"></i> Reportar Área de Risco
              </Link>
              <Link to="/dashboard" className="btn-secondary">
                <i className="fas fa-chart-bar"></i> Ver Dashboard
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <section className="features">
        <div className="container">
          <h2>Como Funciona</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-map-marker-alt"></i>
              </div>
              <h3>Identifique</h3>
              <p>Encontre áreas de risco em sua comunidade que precisam de atenção.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-exclamation-circle"></i>
              </div>
              <h3>Reporte</h3>
              <p>Envie informações detalhadas e fotos da área de risco identificada.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-users"></i>
              </div>
              <h3>Mobilize</h3>
              <p>Compartilhe com a comunidade e autoridades para promover ações.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <i className="fas fa-check-circle"></i>
              </div>
              <h3>Acompanhe</h3>
              <p>Monitore o status das áreas reportadas e as medidas tomadas.</p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="cta">
        <div className="container">
          <h2>Faça Parte da Solução</h2>
          <p>Ajude a tornar Fortaleza uma cidade mais segura para todos.</p>
          <Link to="/register" className="btn-primary">
            <i className="fas fa-user-plus"></i> Cadastre-se Agora
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;

const getCLS = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    console.log('CLS metric called');
  }
};

const getFID = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    console.log('FID metric called');
  }
};

const getFCP = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    console.log('FCP metric called');
  }
};

const getLCP = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    console.log('LCP metric called');
  }
};

const getTTFB = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    console.log('TTFB metric called');
  }
};

export {
  getCLS,
  getFID,
  getFCP,
  getLCP,
  getTTFB
};

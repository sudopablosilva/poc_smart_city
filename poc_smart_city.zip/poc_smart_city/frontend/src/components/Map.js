import React, { useState, useEffect } from 'react';
import './Map.css';

const Map = ({ riskAreas = [] }) => {
  const [loading, setLoading] = useState(true);
  const [mapData, setMapData] = useState({
    center: { lat: -3.731862, lng: -38.526669 }, // Fortaleza
    zoom: 12
  });
  
  useEffect(() => {
    // Simular carregamento do mapa
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const getRiskLevelClass = (level) => {
    const classMap = {
      'low': 'risk-low',
      'medium': 'risk-medium',
      'high': 'risk-high'
    };
    return classMap[level] || '';
  };
  
  if (loading) {
    return (
      <div className="map-container loading">
        <div className="loading-spinner"></div>
        <p>Carregando mapa...</p>
      </div>
    );
  }
  
  return (
    <div className="map-container">
      <div className="map-overlay">
        <h3>Mapa de Fortaleza</h3>
        <p>Visualização de áreas de risco</p>
        
        <div className="map-stats">
          <div className="stat-item">
            <div className="stat-value">{riskAreas.length || 0}</div>
            <div className="stat-label">Áreas Reportadas</div>
          </div>
        </div>
        
        <div className="map-legend">
          <div className="legend-item">
            <span className="legend-color high"></span>
            <span className="legend-label">Alto Risco</span>
          </div>
          <div className="legend-item">
            <span className="legend-color medium"></span>
            <span className="legend-label">Médio Risco</span>
          </div>
          <div className="legend-item">
            <span className="legend-color low"></span>
            <span className="legend-label">Baixo Risco</span>
          </div>
        </div>
      </div>
      
      <div className="map-placeholder">
        {/* Aqui seria renderizado o mapa real com Leaflet ou Google Maps */}
        {/* Por enquanto, usamos uma simulação visual */}
        
        {/* Pontos simulando áreas de risco */}
        {riskAreas.map((area, index) => (
          <div 
            key={area.id || index}
            className={`map-point ${getRiskLevelClass(area.risk_level)}`}
            style={{ 
              top: `${Math.random() * 70 + 15}%`, 
              left: `${Math.random() * 70 + 15}%` 
            }}
            title={area.title}
          ></div>
        ))}
        
        {/* Pontos simulados fixos para demonstração */}
        <div className="map-point risk-high" style={{ top: '30%', left: '40%' }}></div>
        <div className="map-point risk-medium" style={{ top: '50%', left: '60%' }}></div>
        <div className="map-point risk-low" style={{ top: '70%', left: '30%' }}></div>
        <div className="map-point risk-high" style={{ top: '40%', left: '70%' }}></div>
        <div className="map-point risk-medium" style={{ top: '60%', left: '50%' }}></div>
      </div>
      
      <div className="map-controls">
        <button className="map-control-btn zoom-in">
          <i className="fas fa-plus"></i>
        </button>
        <button className="map-control-btn zoom-out">
          <i className="fas fa-minus"></i>
        </button>
        <button className="map-control-btn location">
          <i className="fas fa-location-arrow"></i>
        </button>
      </div>
    </div>
  );
};

export default Map;

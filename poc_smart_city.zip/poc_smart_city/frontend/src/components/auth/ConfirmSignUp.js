import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Auth.css';

const ConfirmSignUp = () => {
  const [username, setUsername] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResending, setIsResending] = useState(false);

  const { confirmSignUp, signUp } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Get username from query params
    const params = new URLSearchParams(location.search);
    const usernameParam = params.get('username');
    if (usernameParam) {
      setUsername(usernameParam);
    }
  }, [location]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!username || !code) {
      setError('Por favor, preencha todos os campos');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      await confirmSignUp(username, code);
      navigate('/login', { state: { confirmed: true } });
    } catch (err) {
      console.error('Confirmation error:', err);
      setError(err.message || 'Erro ao confirmar cadastro');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendCode = async () => {
    if (!username) {
      setError('Por favor, informe o nome de usuário');
      return;
    }
    
    setIsResending(true);
    setError('');
    
    try {
      // This will trigger a new confirmation code to be sent
      await signUp(username, 'dummy-password', 'dummy@email.com');
      alert('Um novo código de confirmação foi enviado para seu email');
    } catch (err) {
      // If the error is because the user already exists, it's actually good
      // because it means the code was resent
      if (err.code === 'UsernameExistsException') {
        alert('Um novo código de confirmação foi enviado para seu email');
      } else {
        console.error('Resend code error:', err);
        setError(err.message || 'Erro ao reenviar código');
      }
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <h2>Confirmar Cadastro</h2>
        <p className="auth-subtitle">
          Digite o código de confirmação enviado para seu email
        </p>
        
        {error && <div className="auth-error">{error}</div>}
        
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="username">Nome de Usuário</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={isSubmitting || isResending}
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="code">Código de Confirmação</label>
            <input
              type="text"
              id="code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              disabled={isSubmitting || isResending}
            />
          </div>
          
          <button
            type="submit"
            className="btn btn-primary auth-button"
            disabled={isSubmitting || isResending}
          >
            {isSubmitting ? 'Confirmando...' : 'Confirmar'}
          </button>
          
          <button
            type="button"
            className="btn btn-secondary auth-button"
            onClick={handleResendCode}
            disabled={isSubmitting || isResending}
          >
            {isResending ? 'Reenviando...' : 'Reenviar Código'}
          </button>
        </form>
        
        <div className="auth-footer">
          <p>
            <Link to="/login" className="auth-link">
              Voltar para o login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ConfirmSignUp;

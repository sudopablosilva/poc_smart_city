import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Auth.css';

const ResetPassword = () => {
  const [step, setStep] = useState(1);
  const [username, setUsername] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { resetPassword, confirmPasswordReset } = useAuth();
  const navigate = useNavigate();

  const handleRequestReset = async (e) => {
    e.preventDefault();
    
    if (!username) {
      setError('Por favor, informe o nome de usuário');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      await resetPassword(username);
      setStep(2);
    } catch (err) {
      console.error('Reset password request error:', err);
      setError(err.message || 'Erro ao solicitar redefinição de senha');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmReset = async (e) => {
    e.preventDefault();
    
    if (!code) {
      setError('Por favor, informe o código de verificação');
      return;
    }
    
    if (!newPassword) {
      setError('Por favor, informe a nova senha');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      setError('As senhas não coincidem');
      return;
    }
    
    if (newPassword.length < 8) {
      setError('A senha deve ter pelo menos 8 caracteres');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      await confirmPasswordReset(username, code, newPassword);
      navigate('/login', { state: { passwordReset: true } });
    } catch (err) {
      console.error('Confirm reset password error:', err);
      setError(err.message || 'Erro ao redefinir senha');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <h2>Redefinir Senha</h2>
        
        {step === 1 ? (
          <>
            <p className="auth-subtitle">
              Informe seu nome de usuário para receber um código de verificação
            </p>
            
            {error && <div className="auth-error">{error}</div>}
            
            <form onSubmit={handleRequestReset} className="auth-form">
              <div className="form-group">
                <label htmlFor="username">Nome de Usuário</label>
                <input
                  type="text"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>
              
              <button
                type="submit"
                className="btn btn-primary auth-button"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Enviando...' : 'Enviar Código'}
              </button>
            </form>
          </>
        ) : (
          <>
            <p className="auth-subtitle">
              Digite o código de verificação enviado para seu email e sua nova senha
            </p>
            
            {error && <div className="auth-error">{error}</div>}
            
            <form onSubmit={handleConfirmReset} className="auth-form">
              <div className="form-group">
                <label htmlFor="code">Código de Verificação</label>
                <input
                  type="text"
                  id="code"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="newPassword">Nova Senha</label>
                <input
                  type="password"
                  id="newPassword"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="confirmPassword">Confirmar Nova Senha</label>
                <input
                  type="password"
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>
              
              <button
                type="submit"
                className="btn btn-primary auth-button"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Redefinindo...' : 'Redefinir Senha'}
              </button>
              
              <button
                type="button"
                className="btn btn-secondary auth-button"
                onClick={() => setStep(1)}
                disabled={isSubmitting}
              >
                Voltar
              </button>
            </form>
          </>
        )}
        
        <div className="auth-footer">
          <p>
            <Link to="/login" className="auth-link">
              Voltar para o login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;

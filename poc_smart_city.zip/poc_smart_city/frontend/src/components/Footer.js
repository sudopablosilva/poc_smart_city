import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section about">
            <h3>Fortaleza Segura</h3>
            <p>Juntos por uma cidade mais segura.</p>
            <div className="contact">
              <p><i className="fas fa-envelope"></i> contato@fortalezasegura.com.br</p>
              <p><i className="fas fa-phone"></i> (85) 9999-9999</p>
            </div>
            <div className="social-links">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
          
          <div className="footer-section links">
            <h3>Links Úteis</h3>
            <ul>
              <li><Link to="/">Início</Link></li>
              <li><Link to="/dashboard">Dashboard</Link></li>
              <li><Link to="/report">Reportar Área</Link></li>
              <li><Link to="/about">Sobre</Link></li>
            </ul>
          </div>
          
          <div className="footer-section contact-form">
            <h3>Contato</h3>
            <form>
              <input type="email" placeholder="Seu email" required />
              <textarea placeholder="Sua mensagem" required></textarea>
              <button type="submit" className="btn-submit">Enviar</button>
            </form>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; {currentYear} Fortaleza Segura. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

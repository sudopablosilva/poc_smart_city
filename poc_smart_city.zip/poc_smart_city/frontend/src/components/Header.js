import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Header.css';
import { userService } from '../services/api';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  // Verificar se o usuário está logado (simulado)
  const isLoggedIn = localStorage.getItem('authToken') !== null;
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const handleLogout = () => {
    userService.logout();
    navigate('/');
  };
  
  return (
    <header className="header">
      <div className="container">
        <div className="header-content">
          <div className="logo">
            <Link to="/">
              <i className="fas fa-shield-alt"></i>
              <span>Fortaleza Segura</span>
            </Link>
          </div>
          
          <button className="menu-toggle" onClick={toggleMenu}>
            <i className={isMenuOpen ? "fas fa-times" : "fas fa-bars"}></i>
          </button>
          
          <nav className={`main-nav ${isMenuOpen ? 'active' : ''}`}>
            <ul>
              <li>
                <Link to="/" onClick={() => setIsMenuOpen(false)}>
                  <i className="fas fa-home"></i> Início
                </Link>
              </li>
              <li>
                <Link to="/dashboard" onClick={() => setIsMenuOpen(false)}>
                  <i className="fas fa-chart-bar"></i> Dashboard
                </Link>
              </li>
              <li>
                <Link to="/report" onClick={() => setIsMenuOpen(false)}>
                  <i className="fas fa-exclamation-triangle"></i> Reportar Área
                </Link>
              </li>
            </ul>
          </nav>
          
          <div className={`auth-buttons ${isMenuOpen ? 'active' : ''}`}>
            {isLoggedIn ? (
              <>
                <Link to="/profile" className="btn-profile" onClick={() => setIsMenuOpen(false)}>
                  <i className="fas fa-user"></i> Perfil
                </Link>
                <button className="btn-logout" onClick={handleLogout}>
                  <i className="fas fa-sign-out-alt"></i> Sair
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-login" onClick={() => setIsMenuOpen(false)}>
                  <i className="fas fa-sign-in-alt"></i> Entrar
                </Link>
                <Link to="/register" className="btn-register" onClick={() => setIsMenuOpen(false)}>
                  <i className="fas fa-user-plus"></i> Cadastrar
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

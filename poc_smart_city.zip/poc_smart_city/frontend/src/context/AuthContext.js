import React, { createContext, useState, useEffect, useContext } from 'react';
import { Auth } from 'aws-amplify';

// Create context
const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Check if user is authenticated on mount
  useEffect(() => {
    checkUser();
  }, []);

  // Check current authentication state
  const checkUser = async () => {
    try {
      setLoading(true);
      const userData = await Auth.currentAuthenticatedUser();
      setUser(userData);
      setError(null);
    } catch (err) {
      setUser(null);
      setError('User not authenticated');
    } finally {
      setLoading(false);
    }
  };

  // Sign in
  const signIn = async (username, password) => {
    try {
      setLoading(true);
      const userData = await Auth.signIn(username, password);
      setUser(userData);
      setError(null);
      return userData;
    } catch (err) {
      setError(err.message || 'Error signing in');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign up
  const signUp = async (username, password, email, attributes = {}) => {
    try {
      setLoading(true);
      const { user: newUser } = await Auth.signUp({
        username,
        password,
        attributes: {
          email,
          ...attributes,
        },
      });
      setError(null);
      return newUser;
    } catch (err) {
      setError(err.message || 'Error signing up');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Confirm sign up
  const confirmSignUp = async (username, code) => {
    try {
      setLoading(true);
      await Auth.confirmSignUp(username, code);
      setError(null);
    } catch (err) {
      setError(err.message || 'Error confirming sign up');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign out
  const signOut = async () => {
    try {
      setLoading(true);
      await Auth.signOut();
      setUser(null);
      setError(null);
    } catch (err) {
      setError(err.message || 'Error signing out');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Reset password
  const resetPassword = async (username) => {
    try {
      setLoading(true);
      await Auth.forgotPassword(username);
      setError(null);
    } catch (err) {
      setError(err.message || 'Error resetting password');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Confirm password reset
  const confirmPasswordReset = async (username, code, newPassword) => {
    try {
      setLoading(true);
      await Auth.forgotPasswordSubmit(username, code, newPassword);
      setError(null);
    } catch (err) {
      setError(err.message || 'Error confirming password reset');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Change password
  const changePassword = async (oldPassword, newPassword) => {
    try {
      setLoading(true);
      const currentUser = await Auth.currentAuthenticatedUser();
      await Auth.changePassword(currentUser, oldPassword, newPassword);
      setError(null);
    } catch (err) {
      setError(err.message || 'Error changing password');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Update user attributes
  const updateUserAttributes = async (attributes) => {
    try {
      setLoading(true);
      const currentUser = await Auth.currentAuthenticatedUser();
      await Auth.updateUserAttributes(currentUser, attributes);
      setError(null);
    } catch (err) {
      setError(err.message || 'Error updating user attributes');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Context value
  const value = {
    user,
    loading,
    error,
    signIn,
    signUp,
    confirmSignUp,
    signOut,
    resetPassword,
    confirmPasswordReset,
    changePassword,
    updateUserAttributes,
    checkUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;

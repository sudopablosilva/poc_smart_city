import axios from 'axios';

// Determine API URL based on environment
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to add auth token
api.interceptors.request.use(
  async (config) => {
    try {
      // Por enquanto, usamos autenticação básica para desenvolvimento
      const token = localStorage.getItem('authToken');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      // User is not authenticated
      console.log('User not authenticated');
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// API endpoints
export const riskAreaService = {
  // Get all risk areas with optional filters
  getAll: (filters = {}) => {
    const params = new URLSearchParams();
    
    // Add filters to params
    Object.keys(filters).forEach(key => {
      if (filters[key]) {
        params.append(key, filters[key]);
      }
    });
    
    return api.get(`/risk-areas/?${params.toString()}`);
  },
  
  // Get a single risk area by ID
  getById: (id) => api.get(`/risk-areas/${id}/`),
  
  // Create a new risk area
  create: (data) => api.post('/risk-areas/', data),
  
  // Update a risk area
  update: (id, data) => api.patch(`/risk-areas/${id}/`, data),
  
  // Delete a risk area
  delete: (id) => api.delete(`/risk-areas/${id}/`),
  
  // Upload an image for a risk area
  uploadImage: (id, formData) => api.post(`/risk-areas/${id}/upload_image/`, formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  }),
  
  // Add a comment to a risk area
  addComment: (id, text) => api.post(`/risk-areas/${id}/add_comment/`, { text }),
  
  // Get statistics
  getStats: () => api.get('/risk-areas/stats/'),
};

export const riskTypeService = {
  // Get all risk types
  getAll: () => api.get('/risk-types/'),
};

export const neighborhoodService = {
  // Get all neighborhoods
  getAll: () => api.get('/neighborhoods/'),
  
  // Search neighborhoods by name
  search: (query) => api.get(`/neighborhoods/?search=${query}`),
};

export const userService = {
  // Get user profile
  getProfile: () => api.get('/profile/'),
  
  // Update user profile
  updateProfile: (id, data) => api.patch(`/profile/${id}/`, data),
  
  // Register a new user
  register: (userData) => api.post('/profile/register/', userData),
  
  // Login
  login: (credentials) => api.post('/auth/login/', credentials),
  
  // Logout
  logout: () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },
};

export default api;

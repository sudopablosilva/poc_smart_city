# Fortaleza Segura - Aplicativo de Reporte de Áreas de Risco

## Visão Geral

Fortaleza Segura é uma aplicação web responsiva que permite aos cidadãos de Fortaleza reportar áreas de risco em seus bairros. A aplicação visa melhorar a segurança pública através da participação cidadã, fornecendo dados valiosos para autoridades locais e criando uma comunidade mais segura e consciente.

## Arquitetura

### Diagrama de Arquitetura

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  React Frontend │────▶│  Django Backend │────▶│ PostgreSQL DB   │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                      AWS Cloud Infrastructure                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Componentes Principais

1. **Frontend (React)**
   - Interface responsiva para dispositivos móveis e desktop
   - Mapa interativo para visualização e reporte de áreas de risco
   - Autenticação de usuários
   - Dashboard para visualização de métricas

2. **Backend (Django)**
   - API RESTful
   - Autenticação e autorização
   - Processamento de dados geoespaciais
   - Integração com serviços AWS

3. **Banco de Dados (PostgreSQL com PostGIS)**
   - Armazenamento de dados de usuários
   - Armazenamento de reportes de áreas de risco
   - Dados geoespaciais

4. **Infraestrutura AWS**
   - Amazon EC2 ou AWS Elastic Beanstalk para hospedagem
   - Amazon RDS para PostgreSQL
   - Amazon S3 para armazenamento de imagens
   - Amazon CloudFront para CDN
   - AWS Lambda para processamento de dados
   - Amazon CloudWatch para monitoramento
   - AWS Cognito para autenticação

## Arquitetura AWS Detalhada

### Fase de Desenvolvimento Local
- React Frontend rodando localmente
- Django Backend rodando localmente
- PostgreSQL em container Docker

### Fase de Produção na AWS

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  CloudFront CDN │────▶│  API Gateway    │────▶│  Lambda         │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                                               │
        │                                               │
┌─────────────────┐                            ┌─────────────────┐
│                 │                            │                 │
│  S3 (Frontend)  │                            │  RDS PostgreSQL │
│                 │                            │                 │
└─────────────────┘                            └─────────────────┘
                                                       │
                                                       │
                                               ┌─────────────────┐
                                               │                 │
                                               │  ElastiCache    │
                                               │                 │
                                               └─────────────────┘
```

1. **Frontend**:
   - Hospedado no Amazon S3
   - Distribuído via Amazon CloudFront para baixa latência
   - Autenticação via Amazon Cognito

2. **Backend**:
   - API Gateway para gerenciamento de API
   - AWS Lambda para execução serverless do código Django
   - Elastic Beanstalk como alternativa para implantação tradicional

3. **Banco de Dados**:
   - Amazon RDS para PostgreSQL com extensão PostGIS
   - Backups automáticos e alta disponibilidade

4. **Armazenamento**:
   - Amazon S3 para imagens e arquivos estáticos
   - Amazon ElastiCache para caching

5. **Monitoramento e Segurança**:
   - Amazon CloudWatch para logs e métricas
   - AWS WAF para proteção contra ataques web
   - AWS Shield para proteção DDoS

## Métricas para Investidores

### Métricas de Impacto Social
- Número de áreas de risco reportadas
- Tempo médio de resposta das autoridades
- Redução de incidentes em áreas monitoradas
- Engajamento comunitário (usuários ativos)

### Métricas de Negócio
- Custo por usuário ativo
- Taxa de crescimento de usuários
- Retenção de usuários
- Tempo médio de sessão

### Métricas Técnicas
- Tempo de resposta da aplicação
- Disponibilidade do sistema
- Custo de infraestrutura
- Escalabilidade sob demanda

## Dashboard para Investidores

O dashboard para investidores incluirá:

1. **Visão Geral**
   - Total de usuários registrados
   - Total de reportes
   - Crescimento mensal
   - Engajamento por bairro

2. **Impacto Social**
   - Mapa de calor de áreas reportadas
   - Estatísticas de resolução de problemas
   - Feedback da comunidade

3. **Financeiro**
   - Custo operacional
   - Custo de aquisição de usuário
   - Projeções de crescimento
   - ROI social

4. **Técnico**
   - Métricas de desempenho
   - Disponibilidade do sistema
   - Escalabilidade

## Plano de Implementação

### Fase 1: Desenvolvimento Local (2-4 semanas)
- [x] Definir arquitetura e tecnologias
- [x] Configurar ambiente de desenvolvimento
- [x] Desenvolver MVP do frontend em React
- [x] Desenvolver API backend em Django
- [x] Configurar banco de dados PostgreSQL
- [x] Implementar testes com Selenium

### Fase 2: Integração e Testes (2-3 semanas)
- [x] Integrar frontend e backend
- [x] Implementar autenticação de usuários
- [x] Desenvolver funcionalidades de geolocalização
- [x] Testes de integração
- [x] Testes de usabilidade

### Fase 3: Implantação AWS (1-2 semanas)
- [ ] Configurar infraestrutura AWS
- [ ] Implantar aplicação em ambiente de staging
- [ ] Testes de carga e performance
- [ ] Ajustes finais

### Fase 4: Lançamento e Monitoramento (Contínuo)
- [ ] Lançamento da aplicação
- [ ] Monitoramento de métricas
- [ ] Coleta de feedback dos usuários
- [ ] Iterações e melhorias

## Considerações de Custo

### Desenvolvimento Local
- Sem custos de infraestrutura cloud

### AWS (Estimativa Mensal)
- AWS Lambda: Pay-per-use (~$20-50/mês para tráfego inicial)
- Amazon RDS: db.t3.micro (~$30/mês)
- Amazon S3: (~$5-10/mês)
- Amazon CloudFront: (~$10-20/mês)
- Amazon Cognito: (Gratuito até 50.000 usuários ativos mensais)
- Amazon CloudWatch: (~$10-15/mês)

**Total Estimado**: $75-125/mês para início de operação

## Melhores Práticas Well-Architected Framework

### Excelência Operacional
- CI/CD para implantação contínua
- Monitoramento abrangente com CloudWatch
- Documentação detalhada

### Segurança
- Autenticação via Cognito
- Criptografia em trânsito e em repouso
- Princípio de menor privilégio para IAM

### Confiabilidade
- Múltiplas zonas de disponibilidade
- Backups automáticos do RDS
- Estratégia de recuperação de desastres

### Eficiência de Performance
- CloudFront para distribuição global
- ElastiCache para reduzir latência
- Arquitetura serverless para escalabilidade

### Otimização de Custos
- Arquitetura serverless para pagar apenas pelo uso
- Instâncias RDS de tamanho adequado
- Monitoramento de custos com AWS Cost Explorer

## Melhores Práticas UX

- Design mobile-first
- Interface intuitiva para reportar problemas
- Feedback visual imediato para ações do usuário
- Mapa interativo fácil de usar
- Acessibilidade WCAG 2.1 AA
- Suporte offline para áreas com conectividade limitada
- Notificações push para atualizações importantes

## Como Executar o Projeto

### Pré-requisitos
- Docker e Docker Compose
- Node.js 16+ (para desenvolvimento local do frontend)
- Python 3.10+ (para desenvolvimento local do backend)

### Executando com Docker Compose
1. Clone o repositório:
   ```
   git clone https://github.com/seu-usuario/fortaleza-segura.git
   cd fortaleza-segura
   ```

2. Inicie os containers:
   ```
   docker-compose up
   ```

3. Acesse:
   - Frontend: http://localhost:3001
   - Backend API: http://localhost:8000/api

### Desenvolvimento Local (sem Docker)

#### Backend
1. Crie um ambiente virtual Python:
   ```
   cd backend
   python -m venv venv
   source venv/bin/activate  # No Windows: venv\Scripts\activate
   ```

2. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

3. Configure o arquivo .env:
   ```
   cp .env.example .env
   # Edite o arquivo .env com suas configurações
   ```

4. Execute as migrações:
   ```
   python manage.py migrate
   ```

5. Crie um superusuário:
   ```
   python manage.py createsuperuser
   ```

6. Execute o servidor:
   ```
   python manage.py runserver
   ```

#### Frontend
1. Instale as dependências:
   ```
   cd frontend
   npm install
   ```

2. Execute o servidor de desenvolvimento:
   ```
   npm start
   ```

## Conclusão

O aplicativo Fortaleza Segura representa uma solução de baixo custo e alto impacto para melhorar a segurança urbana através da participação cidadã. A arquitetura proposta garante escalabilidade, segurança e eficiência de custos, seguindo as melhores práticas do AWS Well-Architected Framework.

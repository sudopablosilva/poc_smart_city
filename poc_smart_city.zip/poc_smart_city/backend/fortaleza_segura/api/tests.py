from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework.test import APIClient
from rest_framework import status
from .models import RiskType, Neighborhood, RiskArea, UserProfile

class RiskTypeTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
        self.client.force_authenticate(user=self.user)
        
        # Criar alguns tipos de risco para testar
        RiskType.objects.create(name='Alagamento', description='Áreas sujeitas a alagamentos')
        RiskType.objects.create(name='Deslizamento', description='Áreas com risco de deslizamento')
        RiskType.objects.create(name='Incêndio', description='Áreas com risco de incêndio')
    
    def test_get_all_risk_types(self):
        """Teste para verificar se todos os tipos de risco são retornados"""
        response = self.client.get(reverse('risktype-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 3)
    
    def test_get_single_risk_type(self):
        """Teste para verificar se um tipo de risco específico é retornado corretamente"""
        risk_type = RiskType.objects.first()
        response = self.client.get(reverse('risktype-detail', args=[risk_type.id]))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['name'], risk_type.name)

class NeighborhoodTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
        self.client.force_authenticate(user=self.user)
        
        # Criar alguns bairros para testar
        Neighborhood.objects.create(name='Centro', population=50000, area=10.5)
        Neighborhood.objects.create(name='Aldeota', population=70000, area=15.2)
        Neighborhood.objects.create(name='Meireles', population=30000, area=8.7)
    
    def test_get_all_neighborhoods(self):
        """Teste para verificar se todos os bairros são retornados"""
        response = self.client.get(reverse('neighborhood-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 3)
    
    def test_search_neighborhood(self):
        """Teste para verificar a funcionalidade de busca de bairros"""
        response = self.client.get(f"{reverse('neighborhood-list')}?search=Aldeota")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['name'], 'Aldeota')

class RiskAreaTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
        self.client.force_authenticate(user=self.user)
        
        # Criar dados necessários para os testes
        self.risk_type = RiskType.objects.create(name='Alagamento', description='Áreas sujeitas a alagamentos')
        self.neighborhood = Neighborhood.objects.create(name='Centro', population=50000, area=10.5)
        
        # Criar algumas áreas de risco para testar
        RiskArea.objects.create(
            title='Área de teste 1',
            description='Descrição da área de teste 1',
            latitude=-3.731862,
            longitude=-38.526669,
            risk_type=self.risk_type,
            risk_level='medium',
            neighborhood=self.neighborhood,
            reporter=self.user
        )
        
        RiskArea.objects.create(
            title='Área de teste 2',
            description='Descrição da área de teste 2',
            latitude=-3.741862,
            longitude=-38.536669,
            risk_type=self.risk_type,
            risk_level='high',
            neighborhood=self.neighborhood,
            reporter=self.user
        )
    
    def test_get_all_risk_areas(self):
        """Teste para verificar se todas as áreas de risco são retornadas"""
        response = self.client.get(reverse('riskarea-list'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
    
    def test_create_risk_area(self):
        """Teste para verificar a criação de uma nova área de risco"""
        data = {
            'title': 'Nova área de risco',
            'description': 'Descrição da nova área de risco',
            'latitude': -3.751862,
            'longitude': -38.546669,
            'risk_type': self.risk_type.id,
            'risk_level': 'low',
            'neighborhood': self.neighborhood.id
        }
        
        response = self.client.post(reverse('riskarea-list'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(RiskArea.objects.count(), 3)
        self.assertEqual(response.data['title'], 'Nova área de risco')
        self.assertEqual(response.data['reporter'], self.user.id)
    
    def test_filter_risk_areas(self):
        """Teste para verificar a filtragem de áreas de risco"""
        response = self.client.get(f"{reverse('riskarea-list')}?risk_level=high")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['risk_level'], 'high')

class UserProfileTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword123'
        )
        self.profile = UserProfile.objects.create(
            user=self.user,
            bio='Biografia de teste',
            phone='(85) 99999-9999',
            address='Rua de Teste, 123'
        )
        self.client.force_authenticate(user=self.user)
    
    def test_get_own_profile(self):
        """Teste para verificar se o usuário pode acessar seu próprio perfil"""
        response = self.client.get(reverse('profile-detail', args=['me']))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['user'], self.user.id)
        self.assertEqual(response.data['bio'], 'Biografia de teste')
    
    def test_update_profile(self):
        """Teste para verificar a atualização do perfil do usuário"""
        data = {
            'bio': 'Nova biografia',
            'phone': '(85) 88888-8888',
            'first_name': 'Nome',
            'last_name': 'Atualizado'
        }
        
        response = self.client.patch(reverse('profile-detail', args=[self.profile.id]), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['bio'], 'Nova biografia')
        self.assertEqual(response.data['phone'], '(85) 88888-8888')
        
        # Verificar se os dados do usuário também foram atualizados
        self.user.refresh_from_db()
        self.assertEqual(self.user.first_name, 'Nome')
        self.assertEqual(self.user.last_name, 'Atualizado')
    
    def test_register_new_user(self):
        """Teste para verificar o registro de um novo usuário"""
        # Desautenticar para testar o registro
        self.client.force_authenticate(user=None)
        
        data = {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'newpassword123',
            'password_confirm': 'newpassword123',
            'first_name': 'New',
            'last_name': 'User'
        }
        
        response = self.client.post(reverse('profile-register'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue('user' in response.data)
        self.assertTrue('access' in response.data)
        
        # Verificar se o usuário foi criado
        self.assertTrue(User.objects.filter(username='newuser').exists())
        
        # Verificar se o perfil foi criado
        new_user = User.objects.get(username='newuser')
        self.assertTrue(UserProfile.objects.filter(user=new_user).exists())

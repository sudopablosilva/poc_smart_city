from rest_framework import serializers
from django.contrib.auth.models import User
from .models import RiskType, Neighborhood, RiskArea, RiskAreaImage, Comment, UserProfile

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'date_joined']

class RiskTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiskType
        fields = '__all__'

class NeighborhoodSerializer(serializers.ModelSerializer):
    class Meta:
        model = Neighborhood
        fields = ['id', 'name', 'geometry', 'population', 'area']

class NeighborhoodListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Neighborhood
        fields = ['id', 'name']

class CommentSerializer(serializers.ModelSerializer):
    author_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Comment
        fields = ['id', 'risk_area', 'author', 'author_name', 'text', 'created_at']
        read_only_fields = ['author']
    
    def get_author_name(self, obj):
        return obj.author.get_full_name() or obj.author.username
    
    def create(self, validated_data):
        validated_data['author'] = self.context['request'].user
        return super().create(validated_data)

class RiskAreaImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiskAreaImage
        fields = ['id', 'risk_area', 'image', 'caption', 'uploaded_at']

class RiskAreaSerializer(serializers.ModelSerializer):
    reporter_name = serializers.SerializerMethodField()
    risk_type_name = serializers.SerializerMethodField()
    neighborhood_name = serializers.SerializerMethodField()
    images = RiskAreaImageSerializer(many=True, read_only=True)
    comments_count = serializers.SerializerMethodField()
    
    class Meta:
        model = RiskArea
        fields = [
            'id', 'title', 'description', 'latitude', 'longitude',
            'risk_type', 'risk_type_name', 'risk_level', 'neighborhood', 
            'neighborhood_name', 'reporter', 'reporter_name', 'created_at', 
            'updated_at', 'status', 'verified_by', 'verified_at', 
            'resolved_at', 'images', 'comments_count'
        ]
        read_only_fields = ['reporter', 'verified_by', 'verified_at', 'resolved_at']
    
    def get_reporter_name(self, obj):
        return obj.reporter.get_full_name() or obj.reporter.username
    
    def get_risk_type_name(self, obj):
        return obj.risk_type.name
    
    def get_neighborhood_name(self, obj):
        return obj.neighborhood.name if obj.neighborhood else None
    
    def get_comments_count(self, obj):
        return obj.comments.count()
    
    def create(self, validated_data):
        validated_data['reporter'] = self.context['request'].user
        return super().create(validated_data)

class RiskAreaListSerializer(serializers.ModelSerializer):
    risk_type_name = serializers.SerializerMethodField()
    neighborhood_name = serializers.SerializerMethodField()
    
    class Meta:
        model = RiskArea
        fields = [
            'id', 'title', 'latitude', 'longitude', 'risk_type', 
            'risk_type_name', 'risk_level', 'neighborhood', 
            'neighborhood_name', 'created_at', 'status'
        ]
    
    def get_risk_type_name(self, obj):
        return obj.risk_type.name
    
    def get_neighborhood_name(self, obj):
        return obj.neighborhood.name if obj.neighborhood else None

class UserProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    email = serializers.EmailField(source='user.email', read_only=True)
    first_name = serializers.CharField(source='user.first_name')
    last_name = serializers.CharField(source='user.last_name')
    neighborhood_name = serializers.SerializerMethodField()
    reported_areas_count = serializers.SerializerMethodField()
    
    class Meta:
        model = UserProfile
        fields = [
            'id', 'user', 'username', 'email', 'first_name', 'last_name',
            'bio', 'phone', 'address', 'neighborhood', 'neighborhood_name',
            'avatar', 'is_public_servant', 'organization', 'reported_areas_count'
        ]
        read_only_fields = ['user']
    
    def get_neighborhood_name(self, obj):
        return obj.neighborhood.name if obj.neighborhood else None
    
    def get_reported_areas_count(self, obj):
        return obj.user.reported_areas.count()
    
    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', {})
        user = instance.user
        
        # Update User model fields
        for attr, value in user_data.items():
            setattr(user, attr, value)
        user.save()
        
        # Update UserProfile model fields
        return super().update(instance, validated_data)

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    password_confirm = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'password_confirm', 'first_name', 'last_name']
    
    def validate(self, data):
        if data['password'] != data['password_confirm']:
            raise serializers.ValidationError({"password_confirm": "Senhas não conferem."})
        return data
    
    def create(self, validated_data):
        validated_data.pop('password_confirm')
        user = User.objects.create_user(**validated_data)
        UserProfile.objects.create(user=user)
        return user

from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from django_filters.rest_framework import DjangoFilterBackend
from django.contrib.auth.models import User
from django.db.models import Count
from django.utils import timezone
from django.shortcuts import get_object_or_404

from .models import RiskType, Neighborhood, RiskArea, RiskAreaImage, Comment, UserProfile
from .serializers import (
    RiskTypeSerializer, NeighborhoodSerializer, NeighborhoodListSerializer,
    RiskAreaSerializer, RiskAreaListSerializer, RiskAreaImageSerializer,
    CommentSerializer, UserProfileSerializer, UserRegistrationSerializer,
    UserSerializer
)

class RiskTypeViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint para listar tipos de risco.
    """
    queryset = RiskType.objects.all()
    serializer_class = RiskTypeSerializer
    permission_classes = [permissions.IsAuthenticated]

class NeighborhoodViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint para listar bairros.
    """
    queryset = Neighborhood.objects.all()
    serializer_class = NeighborhoodSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [filters.SearchFilter]
    search_fields = ['name']
    
    def get_serializer_class(self):
        if self.action == 'list':
            return NeighborhoodListSerializer
        return NeighborhoodSerializer

class RiskAreaViewSet(viewsets.ModelViewSet):
    """
    API endpoint para gerenciar áreas de risco.
    """
    queryset = RiskArea.objects.all()
    serializer_class = RiskAreaSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['risk_type', 'risk_level', 'neighborhood', 'status']
    search_fields = ['title', 'description']
    ordering_fields = ['created_at', 'updated_at', 'risk_level']
    
    def get_serializer_class(self):
        if self.action == 'list':
            return RiskAreaListSerializer
        return RiskAreaSerializer
    
    @action(detail=True, methods=['post'], parser_classes=[MultiPartParser, FormParser])
    def upload_image(self, request, pk=None):
        """
        Upload de imagem para uma área de risco.
        """
        risk_area = self.get_object()
        serializer = RiskAreaImageSerializer(data=request.data)
        
        if serializer.is_valid():
            serializer.save(risk_area=risk_area)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def add_comment(self, request, pk=None):
        """
        Adicionar comentário a uma área de risco.
        """
        risk_area = self.get_object()
        serializer = CommentSerializer(data=request.data, context={'request': request})
        
        if serializer.is_valid():
            serializer.save(risk_area=risk_area)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['get'])
    def comments(self, request, pk=None):
        """
        Listar comentários de uma área de risco.
        """
        risk_area = self.get_object()
        comments = Comment.objects.filter(risk_area=risk_area)
        serializer = CommentSerializer(comments, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def stats(self, request):
        """
        Estatísticas sobre áreas de risco.
        """
        total = RiskArea.objects.count()
        by_status = RiskArea.objects.values('status').annotate(count=Count('id'))
        by_risk_level = RiskArea.objects.values('risk_level').annotate(count=Count('id'))
        by_risk_type = RiskArea.objects.values('risk_type__name').annotate(count=Count('id'))
        recent = RiskArea.objects.filter(created_at__gte=timezone.now() - timezone.timedelta(days=30)).count()
        
        return Response({
            'total': total,
            'by_status': by_status,
            'by_risk_level': by_risk_level,
            'by_risk_type': by_risk_type,
            'recent': recent
        })

class UserProfileViewSet(viewsets.ModelViewSet):
    """
    API endpoint para gerenciar perfis de usuário.
    """
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_staff:
            return UserProfile.objects.all()
        return UserProfile.objects.filter(user=self.request.user)
    
    def get_object(self):
        pk = self.kwargs.get('pk')
        if pk == 'me':
            return self.request.user.profile
        return super().get_object()
    
    @action(detail=False, methods=['post'], permission_classes=[permissions.AllowAny])
    def register(self, request):
        """
        Registrar um novo usuário.
        """
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            
            return Response({
                'user': UserSerializer(user).data,
                'message': 'Usuário registrado com sucesso'
            }, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=False, methods=['post'], permission_classes=[permissions.AllowAny])
    def login(self, request):
        """
        Login de usuário.
        """
        username = request.data.get('username')
        password = request.data.get('password')
        
        user = get_object_or_404(User, username=username)
        if not user.check_password(password):
            return Response({'detail': 'Credenciais inválidas.'}, status=status.HTTP_401_UNAUTHORIZED)
        
        return Response({
            'user': UserSerializer(user).data,
            'message': 'Login realizado com sucesso'
        })

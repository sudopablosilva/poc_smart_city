from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from django.utils import timezone

class RiskType(models.Model):
    """
    Tipos de risco que podem ser reportados (ex: Alagamento, Deslizamento, etc.)
    """
    name = models.CharField(_('Nome'), max_length=100)
    description = models.TextField(_('Descrição'), blank=True)
    icon = models.CharField(_('Ícone'), max_length=50, blank=True, help_text="Nome do ícone FontAwesome")
    color = models.CharField(_('Cor'), max_length=20, blank=True, help_text="Código de cor em hexadecimal")
    
    class Meta:
        verbose_name = _('Tipo de Risco')
        verbose_name_plural = _('Tipos de Risco')
        ordering = ['name']
    
    def __str__(self):
        return self.name

class Neighborhood(models.Model):
    """
    Bairros da cidade de Fortaleza
    """
    name = models.CharField(_('Nome'), max_length=100)
    # Usando TextField para armazenar GeoJSON em vez de GeoDjango
    geometry = models.TextField(_('Geometria GeoJSON'), blank=True)
    population = models.PositiveIntegerField(_('População'), null=True, blank=True)
    area = models.FloatField(_('Área (km²)'), null=True, blank=True)
    
    class Meta:
        verbose_name = _('Bairro')
        verbose_name_plural = _('Bairros')
        ordering = ['name']
    
    def __str__(self):
        return self.name

class RiskArea(models.Model):
    """
    Áreas de risco reportadas pelos usuários
    """
    RISK_LEVELS = (
        ('low', _('Baixo')),
        ('medium', _('Médio')),
        ('high', _('Alto')),
    )
    
    STATUS_CHOICES = (
        ('pending', _('Pendente')),
        ('verified', _('Verificado')),
        ('resolved', _('Resolvido')),
        ('rejected', _('Rejeitado')),
    )
    
    title = models.CharField(_('Título'), max_length=200)
    description = models.TextField(_('Descrição'))
    # Usando campos separados para latitude e longitude em vez de GeoDjango
    latitude = models.FloatField(_('Latitude'))
    longitude = models.FloatField(_('Longitude'))
    risk_type = models.ForeignKey(RiskType, on_delete=models.CASCADE, verbose_name=_('Tipo de Risco'))
    risk_level = models.CharField(_('Nível de Risco'), max_length=10, choices=RISK_LEVELS, default='medium')
    neighborhood = models.ForeignKey(Neighborhood, on_delete=models.SET_NULL, null=True, blank=True, verbose_name=_('Bairro'))
    reporter = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reported_areas', verbose_name=_('Reportado por'))
    created_at = models.DateTimeField(_('Criado em'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Atualizado em'), auto_now=True)
    status = models.CharField(_('Status'), max_length=10, choices=STATUS_CHOICES, default='pending')
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_areas', verbose_name=_('Verificado por'))
    verified_at = models.DateTimeField(_('Verificado em'), null=True, blank=True)
    resolved_at = models.DateTimeField(_('Resolvido em'), null=True, blank=True)
    
    class Meta:
        verbose_name = _('Área de Risco')
        verbose_name_plural = _('Áreas de Risco')
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        # Se o status mudou para verificado, atualiza o timestamp
        if self.status == 'verified' and not self.verified_at:
            self.verified_at = timezone.now()
        
        # Se o status mudou para resolvido, atualiza o timestamp
        if self.status == 'resolved' and not self.resolved_at:
            self.resolved_at = timezone.now()
            
        super().save(*args, **kwargs)

class RiskAreaImage(models.Model):
    """
    Imagens associadas a uma área de risco
    """
    risk_area = models.ForeignKey(RiskArea, on_delete=models.CASCADE, related_name='images', verbose_name=_('Área de Risco'))
    image = models.ImageField(_('Imagem'), upload_to='risk_areas/')
    caption = models.CharField(_('Legenda'), max_length=200, blank=True)
    uploaded_at = models.DateTimeField(_('Enviado em'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('Imagem de Área de Risco')
        verbose_name_plural = _('Imagens de Áreas de Risco')
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"Imagem para {self.risk_area.title}"

class Comment(models.Model):
    """
    Comentários em áreas de risco
    """
    risk_area = models.ForeignKey(RiskArea, on_delete=models.CASCADE, related_name='comments', verbose_name=_('Área de Risco'))
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name=_('Autor'))
    text = models.TextField(_('Texto'))
    created_at = models.DateTimeField(_('Criado em'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('Comentário')
        verbose_name_plural = _('Comentários')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Comentário de {self.author.username} em {self.risk_area.title}"

class UserProfile(models.Model):
    """
    Perfil de usuário com informações adicionais
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile', verbose_name=_('Usuário'))
    bio = models.TextField(_('Biografia'), blank=True)
    phone = models.CharField(_('Telefone'), max_length=20, blank=True)
    address = models.CharField(_('Endereço'), max_length=255, blank=True)
    neighborhood = models.ForeignKey(Neighborhood, on_delete=models.SET_NULL, null=True, blank=True, verbose_name=_('Bairro'))
    avatar = models.ImageField(_('Avatar'), upload_to='avatars/', null=True, blank=True)
    is_public_servant = models.BooleanField(_('É servidor público'), default=False)
    organization = models.CharField(_('Organização'), max_length=100, blank=True)
    
    class Meta:
        verbose_name = _('Perfil de Usuário')
        verbose_name_plural = _('Perfis de Usuário')
    
    def __str__(self):
        return f"Perfil de {self.user.username}"

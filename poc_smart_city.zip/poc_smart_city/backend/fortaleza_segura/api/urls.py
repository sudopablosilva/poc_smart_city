from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'risk-types', views.RiskTypeViewSet)
router.register(r'neighborhoods', views.NeighborhoodViewSet)
router.register(r'risk-areas', views.RiskAreaViewSet)
router.register(r'profile', views.UserProfileViewSet, basename='profile')

urlpatterns = [
    path('', include(router.urls)),
    path('auth/', include('rest_framework.urls')),
]

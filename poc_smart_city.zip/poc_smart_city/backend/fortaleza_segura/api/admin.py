from django.contrib import admin
from .models import RiskType, Neighborhood, RiskArea, RiskAreaImage, Comment, UserProfile

@admin.register(RiskType)
class RiskTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name', 'description')

@admin.register(Neighborhood)
class NeighborhoodAdmin(admin.ModelAdmin):
    list_display = ('name', 'population', 'area')
    search_fields = ('name',)

class RiskAreaImageInline(admin.TabularInline):
    model = RiskAreaImage
    extra = 1

class CommentInline(admin.TabularInline):
    model = Comment
    extra = 0
    readonly_fields = ('author', 'created_at')

@admin.register(RiskArea)
class RiskAreaAdmin(admin.ModelAdmin):
    list_display = ('title', 'risk_type', 'risk_level', 'neighborhood', 'reporter', 'status', 'created_at')
    list_filter = ('risk_type', 'risk_level', 'status', 'neighborhood')
    search_fields = ('title', 'description', 'reporter__username')
    readonly_fields = ('reporter', 'created_at', 'updated_at')
    inlines = [RiskAreaImageInline, CommentInline]
    
    def save_model(self, request, obj, form, change):
        if not change:  # Se é uma nova instância
            obj.reporter = request.user
        super().save_model(request, obj, form, change)

@admin.register(RiskAreaImage)
class RiskAreaImageAdmin(admin.ModelAdmin):
    list_display = ('risk_area', 'caption', 'uploaded_at')
    list_filter = ('uploaded_at',)
    search_fields = ('risk_area__title', 'caption')

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('risk_area', 'author', 'text', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('risk_area__title', 'author__username', 'text')
    readonly_fields = ('author', 'created_at')
    
    def save_model(self, request, obj, form, change):
        if not change:  # Se é um novo comentário
            obj.author = request.user
        super().save_model(request, obj, form, change)

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone', 'neighborhood', 'is_public_servant', 'organization')
    list_filter = ('is_public_servant', 'neighborhood')
    search_fields = ('user__username', 'user__email', 'phone', 'address')

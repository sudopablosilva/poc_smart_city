from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import sys

def test_frontend():
    print("Starting Chrome to test the frontend...")
    
    # Set up Chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Run in headless mode
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--enable-logging")
    chrome_options.add_argument("--v=1")
    
    # Initialize the Chrome driver with the WebDriver Manager
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    
    try:
        # Navigate to the frontend
        print("Navigating to http://localhost:3001/")
        driver.get("http://localhost:3001/")
        
        # Wait for the page to load
        time.sleep(5)
        
        # Get the page source
        page_source = driver.page_source
        
        # Check for error messages in the console logs
        console_logs = driver.get_log('browser')
        errors = [log for log in console_logs if log['level'] == 'SEVERE']
        
        # Print the page title
        print(f"Page title: {driver.title}")
        
        # Check if the root element has any children (indicating React has rendered something)
        root_element = driver.find_element(By.ID, "root")
        root_children = root_element.find_elements(By.XPATH, "./*")
        
        if len(root_children) > 0:
            print("React app has rendered content in the root element")
        else:
            print("React app has NOT rendered any content in the root element")
        
        # Print any errors found
        if errors:
            print("Errors found in console:")
            for error in errors:
                print(f"  {error['message']}")
        else:
            print("No severe errors found in console")
        
        # Check for specific error messages in the page source
        if "Module build failed" in page_source:
            print("Found 'Module build failed' error in page source")
            
            # Extract the error message
            start_idx = page_source.find("Module build failed")
            end_idx = page_source.find("</pre>", start_idx) if "</pre>" in page_source[start_idx:] else len(page_source)
            error_message = page_source[start_idx:end_idx]
            print(f"Error details: {error_message[:200]}...")
        
        return True
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return False
    
    finally:
        # Close the browser
        driver.quit()

if __name__ == "__main__":
    success = test_frontend()
    sys.exit(0 if success else 1)
